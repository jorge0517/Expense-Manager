<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My_Controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
        parent::__construct();
		$this->load->model('User_account');
		$this->load->model('Expenses');
	}
	public function check_login()
	{
		$login = $this->User_account->login($_POST['email'], $_POST['pass']);
		if (!$login)	$this->login("Invalid Email or Password");	
		else
		{
			foreach ($login as $row)
			{
					$this->session->set_userdata('user_id', $row['user_id']);
					$this->session->set_userdata('email', $_POST['email']);
					$this->session->set_userdata('lname', $row['lastname']);
					$this->session->set_userdata('fname', $row['firstname']);
					$this->session->set_userdata('role', $row['role']);
					redirect(base_url().'index.php/My_controller/index');
			}		
		}
	}

	public function logout()
	{
		$this->load->library('session');
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('lname');
		$this->session->unset_userdata('fname');
		$this->session->unset_userdata('role');
		redirect(base_url().'index.php/My_controller/login');
	}

	public function login($message = "")
	{
		$data['currentpage'] = 'login';
		$data['message'] = $message;
		$this->load->view("login", $data);
	}
	
	public function index()
	{
		$this->load->library('session');
		$data['users'] = $this->User_account->users();
		$data['roles'] = $this->User_account->roles();
		$data['category'] = $this->Expenses->category();
		$data['expense'] = $this->Expenses->expenses_list();
		$this->load->view('index',$data);
	}
	public function user_role()
	{
		$data['users'] = $this->User_account->users();
		$data['roles'] = $this->User_account->roles();
		$this->load->view('role',$data);
	}
	public function user_account()
	{
		$data['users'] = $this->User_account->users();
		$data['roles'] = $this->User_account->roles();
		$this->load->view('user',$data);
	}
	public function expense_category()
	{
		$data['users'] = $this->User_account->users();
		$data['roles'] = $this->User_account->roles();
		$data['category'] = $this->Expenses->category();
		$this->load->view('category',$data);
	}
	public function expenses()
	{
		$data['users'] = $this->User_account->users();
		$data['roles'] = $this->User_account->roles();
		$data['category'] = $this->Expenses->category();
		$data['expense'] = $this->Expenses->expenses_list();
		
		$this->load->view('expense',$data);
	}

	//CRUD
	// public function add_role()
	// {

	// }
	//Role
	public function disable_role()
	{
		$this->User_account->disable_role($_GET['id']);
		redirect(base_url().'index.php/My_controller/user_role');
	}
	public function update_role()
	{
		$this->User_account->update_role($_POST['id'],$_POST['name'],$_POST['desc']);
		redirect(base_url().'index.php/My_controller/user_role');
	}
	public function add_role()
	{
		$this->User_account->add_role($_POST['name'],$_POST['desc']);
		redirect(base_url().'index.php/My_controller/user_role');
	}

	//users
	public function disable_user()
	{
		$this->User_account->disable_user($_GET['id']);
		redirect(base_url().'index.php/My_controller/user_account');
	}
	public function update_user()
	{
		$this->User_account->update_user($_POST['id'],$_POST['fname'],$_POST['lname'],$_POST['email'],$_POST['role']);
		redirect(base_url().'index.php/My_controller/user_account');
	}
	public function add_user()
	{
		$this->User_account->add_user($_POST['fname'],$_POST['lname'],$_POST['email'],$_POST['role']);
		redirect(base_url().'index.php/My_controller/user_account');
	}
	public function edit_user()
	{
		$this->User_account->edit_user($_SESSION['user_id'],$_POST['fname'],$_POST['lname'],$_POST['email'],$_POST['pass']);
		redirect(base_url().'index.php/My_controller/index');
	}
	
	//category
	public function disable_category()
	{
		$this->Expenses->disable_category($_GET['id']);
		redirect(base_url().'index.php/My_controller/expense_category');
	}
	public function update_category()
	{
		$this->Expenses->update_category($_POST['id'],$_POST['name'],$_POST['desc']);
		redirect(base_url().'index.php/My_controller/expense_category');
	}
	public function add_category()
	{
		$this->Expenses->add_category($_POST['name'],$_POST['desc']);
		redirect(base_url().'index.php/My_controller/expense_category');
	}
	
	//expense
	public function disable_expense()
	{
		$this->Expenses->disable_expense($_GET['id']);
		redirect(base_url().'index.php/My_controller/expenses');
	}
	public function update_expense()
	{
		$this->Expenses->update_expense($_POST['id'],$_SESSION['user_id'],$_POST['cate_id'],$_POST['amount'],$_POST['edate']);
		redirect(base_url().'index.php/My_controller/expenses');
	}
	public function add_expense()
	{
		$this->Expenses->add_expense($_SESSION['user_id'],$_POST['cate_id'],$_POST['amount'],$_POST['edate']);
		redirect(base_url().'index.php/My_controller/expenses');
	}
	

	
	
}
