<?php
	class Expenses extends CI_Model
	{
		public function category()
		{
			$query = $this->db->query("SELECT * FROM `expense_category_tbl` where status = 'Active';");
			$data = $query->result_array();
			return $data;
		}
        public function expenses_list()
		{
			$query = $this->db->query("SELECT expense_tbl.*,expense_category_tbl.cate_name FROM `expense_tbl` INNER JOIN expense_category_tbl on expense_category_tbl.category_id = expense_tbl.expense_category where expense_tbl.status = 'Active'");
			$data = $query->result_array();
			return $data;
		}
//category
		public function disable_category($id)
		{
			$query = $this->db->query("UPDATE `expense_category_tbl` SET `status` = 'Unactive' WHERE `expense_category_tbl`.`category_id` = $id;");
		}
        public function update_category($id,$name,$desc)
		{
			$query = $this->db->query("UPDATE `expense_category_tbl` SET `cate_name` = '$name', `cate_description` = '$desc' WHERE `expense_category_tbl`.`category_id` = $id;");
		}
        public function add_category($name,$desc)
		{
            $date_now = date('Y-m-d');
			$query = $this->db->query("INSERT INTO `expense_category_tbl` (`category_id`, `cate_name`, `cate_description`, `date_created`, `status`) VALUES (NULL, '$name', '$desc', '$date_now', 'Active');");
		}
        
//expense
        public function disable_expense($id)
        {
            $query = $this->db->query("UPDATE `expense_tbl` SET `status` = 'Unactive' WHERE `expense_tbl`.`expense_id` = $id;");
        }
        public function update_expense($expense_id,$id,$category_id,$amount,$entry_date)
		{
			$query = $this->db->query("UPDATE `expense_tbl` SET `user_id` = '$id', `expense_category` = '$category_id', `amount` = '$amount', `entry_date` = '$entry_date' WHERE `expense_tbl`.`expense_id` = $expense_id;");
		}
        public function add_expense($id,$category_id,$amount,$entry_date)
		{
            $date_now = date('Y-m-d');
			$query = $this->db->query("INSERT INTO `expense_tbl` (`expense_id`, `user_id`, `expense_category`, `amount`, `entry_date`, `date_created`, `status`) VALUES (NULL, '$id', '$category_id', '$amount', '$entry_date', '$date_now', 'Active');");
		}
    }
?>