<?php
	class User_account extends CI_Model
	{
		public function users()
		{
			$query = $this->db->query("SELECT * FROM `users_tbl` where status = 'Active';");
			$data = $query->result_array();
			return $data;
		}
        public function roles()
		{
			$query = $this->db->query("SELECT * FROM `role_tbl` where status = 'Active';");
			$data = $query->result_array();
			return $data;
		}

		public function login($email,$pass)
		{
			$query = $this->db->query("SELECT * FROM `users_tbl` where email='$email' and password='$pass' and status='Active'");
			$data = $query->result_array();
			return $data;
		}
//role
		public function disable_role($id)
		{
			$query = $this->db->query("UPDATE `role_tbl` SET `status` = 'Unactive' WHERE `role_tbl`.`role` = $id;");
		}
        public function update_role($id,$name,$desc)
		{
			$query = $this->db->query("UPDATE `role_tbl` SET `role_name` = '$name', `description` = '$desc' WHERE `role_tbl`.`role` = $id;");
		}
        public function add_role($name,$desc)
		{
            $date_now = date('Y-m-d');
			$query = $this->db->query("INSERT INTO `role_tbl` (`role`, `role_name`, `description`, `date_created`, `status`) VALUES (NULL, '$name', '$desc', '$date_now','Active');");
		}
//user
        public function disable_user($id)
		{
			$query = $this->db->query("UPDATE `users_tbl` SET `status` = 'Unactive' WHERE `users_tbl`.`user_id` = $id;");
		}
        public function update_user($id,$fname,$lname,$email,$role)
		{
			$query = $this->db->query("UPDATE `users_tbl` SET `email` = '$email', `firstname` = '$fname', `lastname` = '$lname', `role` = '$role' WHERE `users_tbl`.`user_id` = $id;");
		}
        public function add_user($fname,$lname,$email,$role)
		{
            $date_now = date('Y-m-d');
			$query = $this->db->query("INSERT INTO `users_tbl` (`user_id`, `email`, `password`, `firstname`, `lastname`, `role`, `status`, `date_created`) VALUES (NULL, '$email', '12345', '$fname', '$lname', '$role', 'Active', '$date_now');");
		}

        public function edit_user($id,$fname,$lname,$email,$pass)
		{
			$query = $this->db->query("UPDATE `users_tbl` SET `email` = '$email', `firstname` = '$fname', `lastname` = '$lname', `password` = '$pass' WHERE `users_tbl`.`user_id` = $id;");
		}
        

        
	}
?>