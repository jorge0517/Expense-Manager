<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>EMS - Users</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url();?>startbootstrap/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url();?>startbootstrap/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="<?php echo base_url();?>startbootstrap/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <?php
    if($_SESSION['user_id']==''){
		redirect(base_url().'index.php/My_controller/login');
    }
    $user_type  = "";
    foreach($roles as $row)
    {
        if($_SESSION['role'] == $row['role']) $user_type= $row['role_name'];
    }
    ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url();?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item active" <?php if($user_type != 'Administrator') echo 'hidden'; ?> >
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#usermanagement"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-users"></i>
                    <span>User Management</span>
                </a>
                <div id="usermanagement" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!-- <h6 class="collapse-header">Custom Components:</h6> -->
                        <a class="collapse-item" href="<?php echo base_url();?>index.php/My_controller/user_role">Roles</a>
                        <a class="collapse-item active" href="<?php echo base_url();?>index.php/My_controller/user_account">Users</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#exmanagement"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-funnel-dollar"></i>
                    <span>Expense Management</span>
                </a>
                <div id="exmanagement" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!-- <h6 class="collapse-header">Custom Components:</h6> -->
                        <a  <?php if($user_type != 'Administrator') echo 'hidden'; ?> class="collapse-item" href="<?php echo base_url();?>index.php/My_controller/expense_category">Expense Categories</a>
                        <a class="collapse-item" href="<?php echo base_url();?>index.php/My_controller/expenses">Expenses</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            
            
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['fname'].' '.$_SESSION['lname'] ?></span>
                                <img class="img-profile rounded-circle"
                                    src="<?php echo base_url();?>startbootstrap/img/profile.png">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Users</h1>
                        <p><span class="d-none d-sm-inline-block">User Management > <a href="<?php echo base_url();?>index.php/My_controller/user_account"> Users</a></span></p>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-9 mb-4">
                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">List of Users</h6>
                                </div>
                                <div class="card-body">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th style='width:150px'>Role</th>
                                            <th style='width:100px'>Created at</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach ($users as $row)
                                        {
                                        $editmod = 'edit-'.$row['user_id'];
                                        $user_role = "";
                                        foreach($roles as $row1)
                                        {
                                            if($row['role'] == $row1['role']) $user_role= $row1['role_name'];
                                        }
                                        echo "
                                        <tr>
                                            <td><a href='#' data-toggle='modal' data-target='#$editmod'>$row[firstname] $row[lastname]</a></td>
                                            <td>$row[email]</td>
                                            <td>$user_role</td>
                                            <td>$row[date_created]</td></a>
                                        </tr>
                                            ";
                                        }
                                        ?>
                                        
                                        
                                    </tbody>
                                </table>
                                <hr>
                                        <a href="#" class="btn btn-primary btn-icon-split float-right" data-toggle="modal" data-target="#addMod">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-plus"></i>
                                        </span>
                                        <span class="text">Add User</span>
                                    </a>
                                </div>
                                    
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?php echo base_url();?>index.php/My_controller/logout">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Modal-->
    <?php
    foreach ($users as $row)
    {
        
    $editmod='edit-'.$row['user_id'];
    echo "
        <div class='modal fade' id='$editmod' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel'
            aria-hidden='true'>
        <div class='modal-dialog' role='document'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='exampleModalLabel'>Update User</h5>
                    <button class='close' type='button' data-dismiss='modal' aria-label='Close'>
                        <span aria-hidden='true'>×</span>
                    </button>
                </div>
                <form method='post' action=".base_url().'index.php/My_controller/update_user'." >
                <div class='modal-body'>
                    <div class='row'>
                        <input type='text' name='id' value='$row[user_id]' hidden required>
                        <div class='col-4 text-dark'>
                            <label>Firstname <span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='text' name='fname' value='$row[firstname]' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Lastname <span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='text' name='lname' value='$row[lastname]' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Email<span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='email' name='email' value='$row[email]' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Role<span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <select class='form-control' type='text' name='role' required>";
                                    foreach($roles as $role)
                                    {
                                        if($role['role']==$row['role'])
                                        echo "<option  value='$role[role]' selected>$role[role_name]</option>";
                                        else
                                        echo "<option  value='$role[role]'>$role[role_name]</option>";
                                    }
                    echo "
                            </select>
                        </div>
                    </div>
                </div>
                <div class='modal-footer'>
                    <a class='btn btn-danger' style='float: left;'  href=".base_url().'index.php/My_controller/disable_user?id='.$row['user_id'].">Delete</a>
                    <button class='btn btn-secondary' type='button' data-dismiss='modal'>Cancel</button>
                    <button class='btn btn-primary' type='submit'>Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>";
    }
    ?>
    <!-- Add Modal-->
    <div class="modal fade" id="addMod" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action='<?php echo base_url();?>index.php/My_controller/add_user'>
                <div class="modal-body">
                    <div class="row">
                    <div class='col-4 text-dark'>
                            <label>Firstname <span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='text' name='fname' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Lastname <span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='text' name='lname' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Email<span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                            <input class='form-control mb-2' type='email' name='email' required>
                        </div>
                        <div class='col-4 text-dark'>
                            <label>Role<span class='text-danger'>*</span></label>
                        </div>
                        <div class='col-8'>
                        <select class='form-control' type='text' name='role' required>";
                            <option value='' selected>-- Select Here --</option>
                            <?php 
                            foreach($roles as $role)
                            {
                                echo "<option  value='$role[role]'>$role[role_name]</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" type="submit">Save</button>
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url();?>startbootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>startbootstrap/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url();?>startbootstrap/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url();?>startbootstrap/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?php echo base_url();?>startbootstrap/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>startbootstrap/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo base_url();?>startbootstrap/js/demo/datatables-demo.js"></script>
  

</body>

</html>